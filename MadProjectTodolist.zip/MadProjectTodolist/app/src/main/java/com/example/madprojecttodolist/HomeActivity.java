package com.example.madprojecttodolist;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.Layout;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener,NavigationView.OnNavigationItemSelectedListener {
    public DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;
    private LinearLayout mLayout;
    private EditText mEditText;
    private FirebaseFirestore db;
    private Button mButton;
    private CheckBox cbox;
    public int checkboxid=0;
    public int textid=0;
    private LinearLayout horizontallayout;
    Button add;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getSupportActionBar().setTitle("Home");
        drawerLayout = findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);
        add = findViewById(R.id.floatingActionButton);
        mLayout = (LinearLayout) findViewById(R.id.listlayout);
        add.setOnClickListener(this);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        db = FirebaseFirestore.getInstance();
        NavigationView nav_view = findViewById(R.id.nav_view);
        nav_view.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                System.out.println("Hello");
                switch (id)
                {
                    case R.id.nav_logout: {
                        FirebaseAuth.getInstance().signOut();
                        //assign a FirbaseUser modules
                        // current user status to variable user
                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        if (user == null) {
                            //Move back to login page if the user is logged out
                            Toast.makeText(com.example.madprojecttodolist.HomeActivity.this, "Logged out.", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(com.example.madprojecttodolist.HomeActivity.this, MainActivity.class);
                            startActivity(i);
                            finish();
                        }
                        break;
                    }
                    case R.id.nav_home:{
                        Intent i = new Intent(com.example.madprojecttodolist.HomeActivity.this, HomeActivity.class);
                        startActivity(i);
                        break;
                    }
                    case R.id.nav_settings: {
                        Intent i = new Intent(com.example.madprojecttodolist.HomeActivity.this, Settings.class);
                        startActivity(i);
                        break;
                    }
                }
                return false;
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onClick(View view) {
        if (view.equals(add)) {
            final LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            horizontallayout = new LinearLayout(this);
            horizontallayout.setOrientation(LinearLayout.HORIZONTAL);
            horizontallayout.setMinimumWidth(LinearLayout.LayoutParams.MATCH_PARENT);
            horizontallayout.setMinimumHeight(LinearLayout.LayoutParams.WRAP_CONTENT);
            horizontallayout.addView(checkbox());
            horizontallayout.addView(createNewTextView());
            mLayout.addView(horizontallayout);
        }

    }
    private CheckBox checkbox()
    {
        final LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(70, LinearLayout.LayoutParams.MATCH_PARENT);
        final CheckBox cb = new CheckBox(this);
        lparams.setMargins(0,20,5,0);
        cb.setLayoutParams(lparams);
        cb.setId(checkboxid);
        checkboxid++;
        return cb;
    }
    private TextView createNewTextView() {
        final LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        final EditText textView = new EditText(this);
        lparams.setMargins(0,20,10,0);
        textView.setBackgroundResource(R.drawable.lists);
        textView.setLayoutParams(lparams);
        textView.setHint(" Enter task here");
        textView.setId(textid);
        textid++;
        return textView;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return false;
    }
}